function [signal_pb, x_decoded] = pulseSHP(x, simParams, mode)
%Description:
% The function had two operational modes: "modulate" / "demodulate"
%   modulate: the function gets coefficients to transmit and apply
%   raised-cosine pulse shaping to create BB signal. later it creates and
%   returns the passBand signal
    
    % --- 1. Parameters ---
    Tsym = simParams.Tsym;
    fc = simParams.fc;
    Fs = simParams.Fs;
    beta = simParams.betha;
    sps = Tsym * Fs; %samples per symbol
    span = 6;
    normalization_factor = 1;
    filterOrder = span * sps; % must be even according to documention
    group_delay = filterOrder / 2; % in GLP filter, the group delay is half the order.

    % --- 2. Filter Design ---
    h_coeff = rcosdesign(beta, span, sps) * sqrt(sps); %taps num is span*sps + 1.
    % also, when upsample by inserting zeros, avg power of signal drops by
    % factor of sps - To maintain the original energy per symbol, scale the filter coefficients.

    if strcmp(mode, 'modulate')
        % ==========================================
        % MODULATION (Baseband to Passband)
        % ==========================================
        % here, x is bb signal
        x_upsamp = upsample(x, sps);
        x_upsamp = [x_upsamp; zeros(group_delay,1)]; % Pad with zeros to flush the Tx filter
        signal_bb = filter(h_coeff, normalization_factor, x_upsamp);
        % Optional: Remove the startup transient to align the Tx signal 
        % so that the first symbol's peak occurs at t=0.
        signal_bb = signal_bb(group_delay + 1 : end);
        t = (0:length(signal_bb)-1)' / Fs;
        x_decoded = [];
        signal_pb = sqrt(2) * real(signal_bb.*exp(1i*2*pi*fc*t));

    elseif strcmp(mode, 'demodulate')
        % ==========================================
        % DEMODULATION (Passband to Baseband)
        % ==========================================
        % here, x is pb signal
        t = (0:length(x)-1)' / Fs;
        mixed_x = x.*exp(-1i*2*pi*fc*t);
        % Pad the mixed signal to flush the Rx matched filter
        mixed_x = [mixed_x; zeros(group_delay, 1)];
        x_bb_filtered = filter(h_coeff, normalization_factor, mixed_x);
        
        % Downsampling
        % We start sampling after the delay and then take 1 sample every 'sps'
        % - Skip the Rx filter's group delay
        % - Multiply by sqrt(2) to reverse the passband power splitting
        % - Divide by 'sps' to reverse the filter gain from using h_coeff twice
        x_decoded = (sqrt(2) / sps) * x_bb_filtered(group_delay + 1 : sps : end);
        signal_pb = [];
    end
end